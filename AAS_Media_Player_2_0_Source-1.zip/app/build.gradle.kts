plugins {
    id("com.android.application")
}

android {
    namespace = "com.aas.mediaplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aas.mediaplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 200
        versionName = "2.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*"
        )
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-session:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
    implementation("androidx.core:core:1.19.1")
    implementation("com.google.guava:guava:33.4.8-android")
}
