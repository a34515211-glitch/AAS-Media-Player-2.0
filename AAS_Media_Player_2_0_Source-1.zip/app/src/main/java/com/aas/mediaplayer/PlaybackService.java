package com.aas.mediaplayer;

import android.os.Handler;
import android.os.Looper;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public final class PlaybackService extends MediaSessionService {
    private static final String PREFS = "aas_media_player_2";
    private ExoPlayer player;
    private MediaSession mediaSession;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable saveProgress = new Runnable() {
        @Override public void run() {
            persistPosition();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        player.setAudioAttributes(
                new AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                true
        );
        player.setHandleAudioBecomingNoisy(true);
        mediaSession = new MediaSession.Builder(this, player).build();
        handler.post(saveProgress);
    }

    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    private void persistPosition() {
        if (player == null) return;
        MediaItem item = player.getCurrentMediaItem();
        if (item == null || item.mediaId == null || item.mediaId.isEmpty()) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("last_uri", item.mediaId)
                .putLong("pos_" + item.mediaId, Math.max(0L, player.getCurrentPosition()))
                .apply();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(saveProgress);
        persistPosition();
        if (mediaSession != null) {
            mediaSession.release();
            mediaSession = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
