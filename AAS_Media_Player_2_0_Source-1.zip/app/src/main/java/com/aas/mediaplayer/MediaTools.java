package com.aas.mediaplayer;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Local audio-track operations. The Android MediaMuxer route is intentionally
 * limited to AAC audio tracks in MP4-compatible sources; unsupported codecs
 * return a clear error instead of creating a corrupt output file.
 */
public final class MediaTools {
    public interface Callback {
        void onSuccess(Uri outputUri, String outputName);
        void onError(String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private MediaTools() { }

    public static void extractAudio(Context context, Uri source, String sourceName, Callback callback) {
        run(context, source, sourceName, 0L, Long.MAX_VALUE, false, true, callback);
    }

    /**
     * keepRange=true: retain samples in [startMs,endMs].
     * keepRange=false: remove samples in [startMs,endMs] and join the remaining audio.
     */
    public static void trimAudio(Context context, Uri source, String sourceName,
                                 long startMs, long endMs, boolean keepRange, Callback callback) {
        if (startMs < 0 || endMs <= startMs) {
            callback.onError("أدخل وقت بداية ونهاية صحيحين.");
            return;
        }
        run(context, source, sourceName, startMs, endMs, keepRange, false, callback);
    }

    private static void run(Context context, Uri source, String sourceName,
                            long startMs, long endMs, boolean keepRange,
                            boolean extractAll, Callback callback) {
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            File temp = new File(app.getCacheDir(), "aas_media_" + System.nanoTime() + ".m4a");
            MediaExtractor extractor = new MediaExtractor();
            MediaMuxer muxer = null;
            boolean muxerStarted = false;
            try {
                extractor.setDataSource(app, source, null);
                int audioTrack = -1;
                MediaFormat audioFormat = null;
                for (int i = 0; i < extractor.getTrackCount(); i++) {
                    MediaFormat format = extractor.getTrackFormat(i);
                    String mime = format.getString(MediaFormat.KEY_MIME);
                    if (mime != null && mime.toLowerCase(Locale.ROOT).startsWith("audio/")) {
                        audioTrack = i;
                        audioFormat = format;
                        break;
                    }
                }
                if (audioTrack < 0 || audioFormat == null) {
                    throw new IllegalArgumentException("لم يحتوِ الملف على مسار صوتي.");
                }
                String mime = audioFormat.getString(MediaFormat.KEY_MIME);
                if (!"audio/mp4a-latm".equals(mime)) {
                    throw new UnsupportedOperationException(
                            "هذه العملية تدعم حالياً مسارات AAC فقط. صيغة الصوت داخل هذا الملف هي: " + mime
                    );
                }

                muxer = new MediaMuxer(temp.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                int outputTrack = muxer.addTrack(audioFormat);
                muxer.start();
                muxerStarted = true;
                extractor.selectTrack(audioTrack);
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

                long startUs = startMs * 1000L;
                long endUs = extractAll ? Long.MAX_VALUE : endMs * 1000L;
                long removedUs = keepRange ? 0L : Math.max(0L, endUs - startUs);
                ByteBuffer buffer = ByteBuffer.allocateDirect(1024 * 1024);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                int written = 0;

                while (true) {
                    buffer.clear();
                    int size = extractor.readSampleData(buffer, 0);
                    if (size < 0) break;
                    long timeUs = extractor.getSampleTime();
                    if (timeUs < 0) break;
                    boolean include;
                    long outputTimeUs = timeUs;
                    if (extractAll) {
                        include = true;
                    } else if (keepRange) {
                        include = timeUs >= startUs && timeUs <= endUs;
                        outputTimeUs = Math.max(0L, timeUs - startUs);
                    } else {
                        include = timeUs < startUs || timeUs > endUs;
                        if (timeUs > endUs) outputTimeUs = Math.max(0L, timeUs - removedUs);
                    }

                    if (include && size > 0) {
                        info.set(0, size, outputTimeUs, extractor.getSampleFlags());
                        muxer.writeSampleData(outputTrack, buffer, info);
                        written++;
                    }
                    if (!extractor.advance()) break;
                }

                if (written == 0) {
                    throw new IllegalArgumentException("لم يتم العثور على عينات صوتية ضمن المدة المحددة.");
                }

                muxer.stop();
                muxerStarted = false;
                muxer.release();
                muxer = null;
                extractor.release();

                String base = safeBaseName(sourceName);
                String outputName = extractAll ? "AAS_" + base + "_audio.m4a" : "AAS_" + base + "_edited.m4a";
                Uri outputUri = publishFile(app, temp, outputName);
                if (outputUri == null) throw new IllegalStateException("تعذر حفظ الملف الناتج.");
                if (!temp.delete()) temp.deleteOnExit();
                callback.onSuccess(outputUri, outputName);
            } catch (Exception e) {
                if (muxer != null) {
                    try {
                        if (muxerStarted) muxer.stop();
                    } catch (Exception ignored) { }
                    try { muxer.release(); } catch (Exception ignored) { }
                }
                try { extractor.release(); } catch (Exception ignored) { }
                // Return a short, useful error without exposing stack traces to the user.
                String message = e.getMessage();
                if (message == null || message.trim().isEmpty()) message = "تعذرت معالجة الملف على هذا الجهاز.";
                callback.onError(message);
                if (temp.exists()) temp.delete();
            }
        });
    }

    private static Uri publishFile(Context context, File source, String displayName) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            values.put(MediaStore.Audio.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MUSIC + "/AAS Media Player");
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            Uri collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri target = resolver.insert(collection, values);
            if (target == null) return null;
            boolean complete = false;
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = resolver.openOutputStream(target, "w")) {
                if (out == null) throw new IllegalStateException("تعذر فتح ملف الحفظ.");
                byte[] data = new byte[64 * 1024];
                int count;
                while ((count = in.read(data)) != -1) out.write(data, 0, count);
                out.flush();
                complete = true;
            } finally {
                if (complete) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Audio.Media.IS_PENDING, 0);
                    resolver.update(target, done, null, null);
                } else {
                    resolver.delete(target, null, null);
                }
            }
            return target;
        }

        File folder = new File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AAS Media Player");
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("تعذر إنشاء مجلد الحفظ.");
        File target = new File(folder, displayName);
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(target)) {
            byte[] data = new byte[64 * 1024];
            int count;
            while ((count = in.read(data)) != -1) out.write(data, 0, count);
            out.flush();
        }
        return Uri.fromFile(target);
    }

    private static String safeBaseName(String name) {
        if (name == null) return "media";
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        base = base.replaceAll("[^\\p{L}\\p{N}_-]", "_");
        if (base.length() > 48) base = base.substring(0, 48);
        return base.isEmpty() ? "media" : base;
    }
}
