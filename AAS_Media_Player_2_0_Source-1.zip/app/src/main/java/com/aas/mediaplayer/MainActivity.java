package com.aas.mediaplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

/** AAS Media Player 2.0 — native Android media library and player. */
public final class MainActivity extends Activity {
    private static final int REQ_AUDIO = 4101;
    private static final int REQ_VIDEO = 4102;
    private static final int REQ_NOTIFICATIONS = 4103;
    private static final String PREFS = "aas_media_player_2";

    private final ArrayList<MediaEntry> library = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            updatePlaybackUi();
            mainHandler.postDelayed(this, 500);
        }
    };

    private SharedPreferences prefs;
    private ListenableFuture<MediaController> controllerFuture;
    private MediaController player;
    private PlayerView playerView;
    private LinearLayout page;
    private LinearLayout libraryRows;
    private LinearLayout playerCard;
    private TextView titleText;
    private TextView statusText;
    private TextView progressText;
    private TextView playButton;
    private SeekBar progressBar;
    private SeekBar speedBar;
    private SeekBar pitchBar;
    private TextView speedValue;
    private TextView pitchValue;
    private EditText searchBox;
    private String activeFilter = "audio";
    private String searchTerm = "";
    private MediaEntry currentEntry;
    private boolean darkTheme = true;
    private boolean english = false;
    private boolean userSeeking = false;
    private boolean repeatAll = false;
    private boolean shuffle = false;
    private boolean sortByName = false;
    private float speed = 1f;
    private float pitch = 1f;
    private Runnable sleepTask;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        darkTheme = prefs.getBoolean("dark", true);
        english = prefs.getBoolean("english", false);
        speed = prefs.getFloat("speed", 1f);
        pitch = prefs.getFloat("pitch", 1f);
        loadLibrary();
        getWindow().setStatusBarColor(bgColor());
        getWindow().setNavigationBarColor(bgColor());
        buildScreen();
        connectPlaybackService();
        requestNotificationPermissionIfNeeded();
        mainHandler.post(progressRunnable);
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutDirection(english ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL);
        page.setPadding(dp(16), dp(14), dp(16), dp(24));
        page.setBackgroundColor(bgColor());
        scroll.addView(page);

        LinearLayout header = horizontal();
        TextView brand = text("AAS Media Player", 21, true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button settings = button(t("الإعدادات", "Settings"));
        settings.setOnClickListener(v -> showSettings());
        header.addView(settings);
        page.addView(header);

        TextView sub = text(t("مكتبة الوسائط الخاصة بك", "Your personal media library"), 13, false);
        sub.setTextColor(mutedColor());
        page.addView(sub);

        LinearLayout resumeCard = card();
        addHeading(resumeCard, t("استئناف التشغيل", "Resume playback"));
        TextView resumeInfo = text(t("اضغط للعودة إلى آخر ملف وموضع توقفت عنده", "Return to the last file and saved position"), 13, false);
        resumeInfo.setTextColor(mutedColor());
        resumeCard.addView(resumeInfo);
        Button resume = primaryButton(t("متابعة آخر تشغيل", "Resume last item"));
        resume.setOnClickListener(v -> resumeLast());
        resumeCard.addView(resume);
        page.addView(resumeCard);

        LinearLayout addCard = card();
        addHeading(addCard, t("إضافة ملفات", "Add media"));
        LinearLayout addButtons = horizontal();
        Button addAudio = primaryButton(t("＋ إضافة صوت", "＋ Add audio"));
        addAudio.setOnClickListener(v -> openPicker(REQ_AUDIO));
        Button addVideo = button(t("＋ إضافة فيديو", "＋ Add video"));
        addVideo.setOnClickListener(v -> openPicker(REQ_VIDEO));
        addButtons.addView(addAudio, weightParams());
        addButtons.addView(addVideo, weightParams());
        addCard.addView(addButtons);
        page.addView(addCard);

        LinearLayout libraryCard = card();
        addHeading(libraryCard, t("المكتبة", "Library"));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextColor(textColor());
        searchBox.setHintTextColor(mutedColor());
        searchBox.setHint(t("ابحث باسم الملف…", "Search by file name…"));
        searchBox.setBackground(inputBackground());
        searchBox.setPadding(dp(12), dp(8), dp(12), dp(8));
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchTerm = s.toString().toLowerCase(Locale.ROOT);
                renderLibrary();
            }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        libraryCard.addView(searchBox);

        LinearLayout filters = horizontal();
        addFilter(filters, t("الصوت", "Audio"), "audio");
        addFilter(filters, t("الفيديو", "Video"), "video");
        addFilter(filters, t("المهملات", "Trash"), "trash");
        Button sort = button(t("ترتيب الحلقات", "Sort episodes"));
        sort.setOnClickListener(v -> {
            sortByName = !sortByName;
            sort.setText(sortByName ? t("ترتيب افتراضي", "Default order") : t("ترتيب الحلقات", "Sort episodes"));
            renderLibrary();
        });
        filters.addView(sort, weightParams());
        libraryCard.addView(filters);
        libraryRows = new LinearLayout(this);
        libraryRows.setOrientation(LinearLayout.VERTICAL);
        libraryRows.setPadding(0, dp(8), 0, 0);
        libraryCard.addView(libraryRows);
        page.addView(libraryCard);

        playerCard = card();
        addHeading(playerCard, t("المشغل الحالي", "Now playing"));
        titleText = text(t("لم يتم اختيار ملف", "No file selected"), 16, true);
        playerCard.addView(titleText);
        statusText = text(t("جاهز للتشغيل", "Ready to play"), 12, false);
        statusText.setTextColor(mutedColor());
        playerCard.addView(statusText);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setVisibility(View.GONE);
        LinearLayout.LayoutParams pv = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        pv.topMargin = dp(8);
        playerCard.addView(playerView, pv);

        LinearLayout transport = horizontal();
        Button previous = button("⏮");
        previous.setContentDescription(t("السابق", "Previous"));
        previous.setOnClickListener(v -> { if (player != null) player.seekToPreviousMediaItem(); });
        playButton = button("▶");
        playButton.setTextSize(21);
        playButton.setOnClickListener(v -> togglePlayback());
        Button next = button("⏭");
        next.setContentDescription(t("التالي", "Next"));
        next.setOnClickListener(v -> { if (player != null) player.seekToNextMediaItem(); });
        Button repeat = button("↻");
        repeat.setContentDescription(t("تكرار القائمة", "Repeat all"));
        repeat.setOnClickListener(v -> {
            repeatAll = !repeatAll;
            if (player != null) player.setRepeatMode(repeatAll ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF);
            repeat.setText(repeatAll ? "↻ ✓" : "↻");
        });
        Button shuffleButton = button("⤨");
        shuffleButton.setContentDescription(t("تشغيل عشوائي", "Shuffle"));
        shuffleButton.setOnClickListener(v -> {
            shuffle = !shuffle;
            if (player != null) player.setShuffleModeEnabled(shuffle);
            shuffleButton.setText(shuffle ? "⤨ ✓" : "⤨");
        });
        transport.addView(previous, weightParams());
        transport.addView(playButton, weightParams());
        transport.addView(next, weightParams());
        transport.addView(repeat, weightParams());
        transport.addView(shuffleButton, weightParams());
        playerCard.addView(transport);

        progressBar = new SeekBar(this);
        progressBar.setMax(1000);
        progressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser && player != null && player.getDuration() > 0) {
                    long position = player.getDuration() * value / 1000L;
                    progressText.setText(formatTime(position) + " / " + formatTime(player.getDuration()));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                userSeeking = false;
                if (player != null && player.getDuration() > 0) {
                    player.seekTo(player.getDuration() * bar.getProgress() / 1000L);
                    savePlaybackState();
                }
            }
        });
        playerCard.addView(progressBar);
        progressText = text("0:00 / 0:00", 12, false);
        progressText.setTextColor(mutedColor());
        playerCard.addView(progressText);

        speedValue = text(t("سرعة التشغيل: 1.00×", "Speed: 1.00×"), 13, true);
        playerCard.addView(speedValue);
        speedBar = new SeekBar(this);
        speedBar.setMax(250);
        speedBar.setProgress(100);
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (!fromUser) return;
                speed = Math.max(0.25f, value / 100f);
                applyPlaybackParameters();
                speedValue.setText(t("سرعة التشغيل: ", "Speed: ") + String.format(Locale.US, "%.2f×", speed));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { prefs.edit().putFloat("speed", speed).apply(); }
        });
        playerCard.addView(speedBar);

        pitchValue = text(t("طبقة الصوت: 1.00", "Pitch: 1.00"), 13, true);
        playerCard.addView(pitchValue);
        pitchBar = new SeekBar(this);
        pitchBar.setMax(200);
        pitchBar.setProgress(100);
        pitchBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (!fromUser) return;
                pitch = Math.max(0.5f, value / 100f);
                applyPlaybackParameters();
                pitchValue.setText(t("طبقة الصوت: ", "Pitch: ") + String.format(Locale.US, "%.2f", pitch));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { prefs.edit().putFloat("pitch", pitch).apply(); }
        });
        playerCard.addView(pitchBar);

        LinearLayout operations = horizontal();
        Button trim = button(t("قص الصوت", "Trim audio"));
        trim.setOnClickListener(v -> showTrimDialog());
        Button extract = button(t("استخراج صوت الفيديو", "Extract video audio"));
        extract.setOnClickListener(v -> extractCurrentVideoAudio());
        Button sleep = button(t("مؤقت النوم", "Sleep timer"));
        sleep.setOnClickListener(v -> showSleepDialog());
        operations.addView(trim, weightParams());
        operations.addView(extract, weightParams());
        operations.addView(sleep, weightParams());
        playerCard.addView(operations);
        LinearLayout extraOperations = horizontal();
        Button rewind = button("−10s");
        rewind.setContentDescription(t("تراجع عشر ثوانٍ", "Back 10 seconds"));
        rewind.setOnClickListener(v -> {
            if (player != null && player.getCurrentMediaItem() != null)
                player.seekTo(Math.max(0L, player.getCurrentPosition() - 10_000L));
        });
        Button forward = button("+10s");
        forward.setContentDescription(t("تقديم عشر ثوانٍ", "Forward 10 seconds"));
        forward.setOnClickListener(v -> {
            if (player != null && player.getCurrentMediaItem() != null) {
                long duration = Math.max(0L, player.getDuration());
                long target = player.getCurrentPosition() + 10_000L;
                player.seekTo(duration > 0 ? Math.min(duration, target) : target);
            }
        });
        Button share = button(t("مشاركة الملف", "Share file"));
        share.setOnClickListener(v -> shareCurrentFile());
        extraOperations.addView(rewind, weightParams());
        extraOperations.addView(forward, weightParams());
        extraOperations.addView(share, weightParams());
        playerCard.addView(extraOperations);
        page.addView(playerCard);

        LinearLayout tools = card();
        addHeading(tools, t("أدوات إضافية", "More tools"));
        Button tts = button(t("تحويل النص إلى ملف صوتي", "Convert text to an audio file"));
        tts.setOnClickListener(v -> showTtsDialog());
        Button info = button(t("معلومات وحدود معالجة الملفات", "Processing information and limits"));
        info.setOnClickListener(v -> showProcessingInfo());
        tools.addView(tts);
        tools.addView(info);
        page.addView(tools);

        setContentView(scroll);
        renderLibrary();
        applyPlaybackParameters();
    }

    private void connectPlaybackService() {
        SessionToken token = new SessionToken(this,
                new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        Executor mainExecutor = command -> mainHandler.post(command);
        controllerFuture.addListener(() -> {
            try {
                player = controllerFuture.get();
                player.addListener(new Player.Listener() {
                    @Override public void onMediaItemTransition(@Nullable MediaItem item, int reason) {
                        if (item != null) {
                            currentEntry = findEntry(item.mediaId);
                            if (currentEntry != null) titleText.setText(currentEntry.name);
                            savePlaybackState();
                            updatePlayerVisibility();
                        }
                        updatePlaybackUi();
                    }
                    @Override public void onIsPlayingChanged(boolean isPlaying) { updatePlaybackUi(); }
                    @Override public void onPlaybackStateChanged(int state) { updatePlaybackUi(); }
                    @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
                        showToast(t("تعذر تشغيل هذا الملف: ", "Could not play this file: ") + error.getErrorCodeName());
                    }
                });
                playerView.setPlayer(player);
                player.setRepeatMode(repeatAll ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF);
                player.setShuffleModeEnabled(shuffle);
                applyPlaybackParameters();
                updatePlaybackUi();
                if (player.getCurrentMediaItem() != null) {
                    currentEntry = findEntry(player.getCurrentMediaItem().mediaId);
                    if (currentEntry != null) titleText.setText(currentEntry.name);
                    updatePlayerVisibility();
                } else {
                    String lastUri = prefs.getString("last_uri", null);
                    if (lastUri != null) {
                        MediaEntry last = findEntry(lastUri);
                        if (last != null) titleText.setText(last.name);
                    }
                }
            } catch (Exception e) {
                showToast(t("تعذر الاتصال بخدمة التشغيل.", "Could not connect to playback service."));
            }
        }, mainExecutor);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void addFilter(LinearLayout parent, String label, String key) {
        Button b = button(label);
        b.setOnClickListener(v -> {
            activeFilter = key;
            renderLibrary();
        });
        parent.addView(b, weightParams());
    }

    private void openPicker(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(requestCode == REQ_AUDIO ? "audio/*" : "video/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            showToast(t("لا يوجد تطبيق لاختيار الملفات.", "No file picker is available."));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || (requestCode != REQ_AUDIO && requestCode != REQ_VIDEO)) return;
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                persistPermission(uri, flags);
                addUriToLibrary(uri);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            persistPermission(uri, flags);
            addUriToLibrary(uri);
        }
        saveLibrary();
        renderLibrary();
    }

    private void persistPermission(Uri uri, int flags) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some document providers grant a non-persistable URI; playback will show a clear error if revoked.
        }
    }

    private void addUriToLibrary(Uri uri) {
        String uriText = uri.toString();
        if (findEntry(uriText) != null) return;
        String name = uri.getLastPathSegment() == null ? "media" : uri.getLastPathSegment();
        long size = 0;
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int nameCol = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeCol = c.getColumnIndex(OpenableColumns.SIZE);
                if (nameCol >= 0 && !c.isNull(nameCol)) name = c.getString(nameCol);
                if (sizeCol >= 0 && !c.isNull(sizeCol)) size = c.getLong(sizeCol);
            }
        } catch (Exception ignored) { }
        String mime = getContentResolver().getType(uri);
        String lower = (mime == null ? "" : mime).toLowerCase(Locale.ROOT);
        String lowerName = name.toLowerCase(Locale.ROOT);
        boolean video = lower.startsWith("video/") || lowerName.matches(".*\\.(mp4|mkv|mov|webm|avi|3gp|m4v)$");
        library.add(new MediaEntry(uriText, name, mime == null ? "application/octet-stream" : mime,
                video ? "video" : "audio", size, false));
    }

    private void addGeneratedFile(Uri uri, String name) {
        String uriText = uri.toString();
        if (findEntry(uriText) == null) {
            long size = 0;
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) size = c.getLong(0);
            } catch (Exception ignored) { }
            library.add(new MediaEntry(uriText, name, "audio/mp4", "audio", size, false));
            saveLibrary();
            renderLibrary();
        }
    }

    private void renderLibrary() {
        if (libraryRows == null) return;
        libraryRows.removeAllViews();
        ArrayList<MediaEntry> shown = new ArrayList<>();
        for (MediaEntry item : library) {
            boolean matchFilter = "trash".equals(activeFilter) ? item.trashed :
                    !item.trashed && activeFilter.equals(item.kind);
            if (matchFilter && item.name.toLowerCase(Locale.ROOT).contains(searchTerm)) shown.add(item);
        }
        if (sortByName) shown.sort((a, b) -> naturalCompare(a.name, b.name));
        if (shown.isEmpty()) {
            TextView empty = text("trash".equals(activeFilter)
                    ? t("سلة المهملات فارغة.", "Trash is empty.")
                    : t("لا توجد ملفات هنا. أضف ملفات من الأزرار أعلاه.", "No files here yet. Add media using the buttons above."), 13, false);
            empty.setTextColor(mutedColor());
            empty.setPadding(dp(4), dp(12), dp(4), dp(12));
            libraryRows.addView(empty);
            return;
        }
        for (MediaEntry item : shown) {
            LinearLayout row = horizontal();
            row.setPadding(dp(8), dp(8), dp(8), dp(8));
            row.setBackground(cardBackground());
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(item.name, 14, true);
            name.setMaxLines(2);
            TextView meta = text(("video".equals(item.kind) ? t("فيديو", "Video") : t("صوت", "Audio"))
                    + "  •  " + readableSize(item.size), 11, false);
            meta.setTextColor(mutedColor());
            details.addView(name);
            details.addView(meta);
            row.addView(details, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            Button action = button(item.trashed ? t("استعادة", "Restore") : t("تشغيل", "Play"));
            action.setOnClickListener(v -> {
                if (item.trashed) item.trashed = false;
                else playEntry(item);
                saveLibrary();
                renderLibrary();
            });
            row.addView(action);
            Button remove = button(item.trashed ? "×" : "⋮");
            remove.setContentDescription(item.trashed ? t("إزالة من المكتبة", "Remove from library") : t("نقل إلى المهملات", "Move to trash"));
            remove.setOnClickListener(v -> {
                if (item.trashed) {
                    library.remove(item);
                    prefs.edit().remove("pos_" + item.uri).apply();
                } else {
                    item.trashed = true;
                }
                saveLibrary();
                renderLibrary();
            });
            row.addView(remove);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(7);
            libraryRows.addView(row, rowLp);
        }
    }

    private void playEntry(MediaEntry entry) {
        if (player == null) {
            showToast(t("خدمة التشغيل قيد الاتصال، حاول مرة أخرى بعد لحظة.", "Playback service is connecting; try again in a moment."));
            return;
        }
        ArrayList<MediaEntry> queue = new ArrayList<>();
        for (MediaEntry item : library) if (!item.trashed && item.kind.equals(entry.kind)) queue.add(item);
        if (sortByName) queue.sort((a, b) -> naturalCompare(a.name, b.name));
        int index = queue.indexOf(entry);
        if (index < 0) return;
        List<MediaItem> mediaItems = new ArrayList<>();
        for (MediaEntry item : queue) {
            MediaMetadata metadata = new MediaMetadata.Builder().setTitle(item.name).build();
            mediaItems.add(new MediaItem.Builder()
                    .setMediaId(item.uri)
                    .setUri(Uri.parse(item.uri))
                    .setMediaMetadata(metadata)
                    .build());
        }
        long position = prefs.getLong("pos_" + entry.uri, 0L);
        currentEntry = entry;
        titleText.setText(entry.name);
        statusText.setText(t("جاري التحضير…", "Preparing…"));
        updatePlayerVisibility();
        try {
            player.setMediaItems(mediaItems, index, position);
            player.prepare();
            player.play();
            prefs.edit().putString("last_uri", entry.uri).apply();
            renderLibrary();
        } catch (Exception e) {
            showToast(t("تعذر فتح الملف. تحقق من صلاحية الوصول إليه.", "Could not open this file. Check its access permission."));
        }
    }

    private void resumeLast() {
        String lastUri = prefs.getString("last_uri", null);
        if (lastUri == null) {
            showToast(t("لم يبدأ أي تشغيل سابق.", "There is no previous playback yet."));
            return;
        }
        MediaEntry item = findEntry(lastUri);
        if (item == null || item.trashed) {
            showToast(t("الملف السابق غير موجود في المكتبة.", "The previous item is no longer in the library."));
            return;
        }
        playEntry(item);
    }

    private void togglePlayback() {
        if (player == null || player.getCurrentMediaItem() == null) {
            showToast(t("اختر ملفاً أولاً.", "Choose a file first."));
            return;
        }
        if (player.isPlaying()) player.pause(); else player.play();
        updatePlaybackUi();
    }

    private void updatePlayerVisibility() {
        if (playerView == null || currentEntry == null) return;
        playerView.setVisibility("video".equals(currentEntry.kind) ? View.VISIBLE : View.GONE);
    }

    private void updatePlaybackUi() {
        if (player == null || playButton == null) return;
        boolean playing = player.isPlaying();
        playButton.setText(playing ? "Ⅱ" : "▶");
        if (player.getCurrentMediaItem() == null) {
            if (statusText != null) statusText.setText(t("جاهز للتشغيل", "Ready to play"));
            return;
        }
        long duration = player.getDuration();
        long position = player.getCurrentPosition();
        if (duration < 0) duration = 0;
        if (position < 0) position = 0;
        if (progressBar != null && !userSeeking) {
            progressBar.setProgress(duration > 0 ? (int) Math.min(1000L, position * 1000L / duration) : 0);
        }
        if (progressText != null) progressText.setText(formatTime(position) + " / " + formatTime(duration));
        if (statusText != null) statusText.setText(playing ? t("قيد التشغيل", "Playing") : t("متوقف مؤقتاً", "Paused"));
        if (currentEntry != null) savePlaybackState();
    }

    private void savePlaybackState() {
        if (player == null || player.getCurrentMediaItem() == null) return;
        String uri = player.getCurrentMediaItem().mediaId;
        if (uri == null || uri.isEmpty()) return;
        prefs.edit().putString("last_uri", uri)
                .putLong("pos_" + uri, Math.max(0, player.getCurrentPosition())).apply();
    }

    private void applyPlaybackParameters() {
        if (player != null) {
            try { player.setPlaybackParameters(new PlaybackParameters(speed, pitch)); }
            catch (Exception ignored) { }
        }
        if (speedBar != null && !userSeeking) speedBar.setProgress(Math.max(25, Math.min(250, (int) (speed * 100))));
        if (pitchBar != null) pitchBar.setProgress(Math.max(50, Math.min(200, (int) (pitch * 100))));
        if (speedValue != null) speedValue.setText(t("سرعة التشغيل: ", "Speed: ") + String.format(Locale.US, "%.2f×", speed));
        if (pitchValue != null) pitchValue.setText(t("طبقة الصوت: ", "Pitch: ") + String.format(Locale.US, "%.2f", pitch));
    }

    private void shareCurrentFile() {
        if (currentEntry == null) {
            showToast(t("اختر ملفاً أولاً.", "Choose a file first."));
            return;
        }
        try {
            Uri shareUri = Uri.parse(currentEntry.uri);
            if ("file".equalsIgnoreCase(shareUri.getScheme())) {
                File file = new File(shareUri.getPath());
                shareUri = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", file);
            }
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(currentEntry.mime == null ? "*/*" : currentEntry.mime);
            send.putExtra(Intent.EXTRA_STREAM, shareUri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, t("مشاركة الملف", "Share media file")));
        } catch (Exception e) {
            showToast(t("تعذرت مشاركة هذا الملف.", "Could not share this file."));
        }
    }

    /** Numeric-aware filename ordering, useful for episode names such as 2 and 10. */
    private int naturalCompare(String left, String right) {
        String a = left == null ? "" : left.toLowerCase(Locale.ROOT);
        String b = right == null ? "" : right.toLowerCase(Locale.ROOT);
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char ca = a.charAt(i), cb = b.charAt(j);
            if (Character.isDigit(ca) && Character.isDigit(cb)) {
                int ai = i, bj = j;
                while (ai < a.length() && a.charAt(ai) == '0') ai++;
                while (bj < b.length() && b.charAt(bj) == '0') bj++;
                int ae = ai, be = bj;
                while (ae < a.length() && Character.isDigit(a.charAt(ae))) ae++;
                while (be < b.length() && Character.isDigit(b.charAt(be))) be++;
                int al = ae - ai, bl = be - bj;
                if (al != bl) return Integer.compare(al, bl);
                for (int k = 0; k < al; k++) {
                    int diff = Character.compare(a.charAt(ai + k), b.charAt(bj + k));
                    if (diff != 0) return diff;
                }
                i = ae;
                j = be;
            } else {
                if (ca != cb) return Character.compare(ca, cb);
                i++;
                j++;
            }
        }
        return Integer.compare(a.length() - i, b.length() - j);
    }

    private void showTrimDialog() {
        if (currentEntry == null || !"audio".equals(currentEntry.kind)) {
            showToast(t("اختر ملفاً صوتياً أولاً.", "Select an audio file first."));
            return;
        }
        long duration = player == null ? 0 : Math.max(0, player.getDuration());
        LinearLayout form = dialogForm();
        addLabel(form, t("البداية بالثواني", "Start in seconds"));
        EditText startInput = numberInput("0");
        form.addView(startInput);
        addLabel(form, t("النهاية بالثواني", "End in seconds"));
        EditText endInput = numberInput(duration > 0 ? String.valueOf(duration / 1000.0) : "30");
        form.addView(endInput);
        RadioGroup mode = new RadioGroup(this);
        RadioButton keep = new RadioButton(this);
        keep.setText(t("الاحتفاظ بالجزء المحدد فقط", "Keep only the selected range"));
        keep.setTextColor(textColor());
        keep.setId(View.generateViewId());
        RadioButton remove = new RadioButton(this);
        remove.setText(t("حذف الجزء المحدد وضم ما قبله وما بعده", "Remove the selected range and join the rest"));
        remove.setTextColor(textColor());
        remove.setId(View.generateViewId());
        mode.addView(keep);
        mode.addView(remove);
        keep.setChecked(true);
        form.addView(mode);
        TextView hint = text(t("القص هنا يعيد حفظ ملف AAC داخل حاوية M4A. الصيغ الأخرى قد لا تكون قابلة للتحرير بهذا المسار.",
                "Trimming exports AAC audio into an M4A file. Other codecs may not be supported by this method."), 12, false);
        hint.setTextColor(mutedColor());
        form.addView(hint);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("قص أو إزالة جزء من الصوت", "Trim or remove an audio section"))
                .setView(form)
                .setNegativeButton(t("إلغاء", "Cancel"), null)
                .setPositiveButton(t("تنفيذ", "Process"), null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                long start = (long) (Double.parseDouble(startInput.getText().toString()) * 1000.0);
                long end = (long) (Double.parseDouble(endInput.getText().toString()) * 1000.0);
                if (end <= start) throw new IllegalArgumentException();
                if (duration > 0 && end > duration) throw new IllegalArgumentException();
                if (player != null) player.pause();
                dialog.dismiss();
                showToast(t("بدأت معالجة الصوت…", "Audio processing started…"));
                MediaTools.trimAudio(this, Uri.parse(currentEntry.uri), currentEntry.name,
                        start, end, keep.isChecked(), new MediaTools.Callback() {
                            @Override public void onSuccess(Uri outputUri, String outputName) {
                                runOnUiThread(() -> {
                                    addGeneratedFile(outputUri, outputName);
                                    showToast(t("تم حفظ الملف المعدل في مكتبة التطبيق.", "Edited file saved to the app library."));
                                });
                            }
                            @Override public void onError(String message) {
                                runOnUiThread(() -> showToast(t("فشل القص: ", "Trim failed: ") + message));
                            }
                        });
            } catch (Exception e) {
                startInput.setError(t("قيمة غير صحيحة", "Invalid value"));
                endInput.setError(t("تحقق من الأوقات", "Check the times"));
            }
        }));
        dialog.show();
    }

    private void extractCurrentVideoAudio() {
        if (currentEntry == null || !"video".equals(currentEntry.kind)) {
            showToast(t("شغّل فيديو أولاً لاستخراج صوته.", "Play a video first to extract its audio."));
            return;
        }
        if (player != null) player.pause();
        MediaTools.extractAudio(this, Uri.parse(currentEntry.uri), currentEntry.name, new MediaTools.Callback() {
            @Override public void onSuccess(Uri outputUri, String outputName) {
                runOnUiThread(() -> {
                    addGeneratedFile(outputUri, outputName);
                    showToast(t("تم استخراج المسار الصوتي وحفظه.", "Audio track extracted and saved."));
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> showToast(t("تعذر استخراج الصوت: ", "Audio extraction failed: ") + message));
            }
        });
        showToast(t("بدأ استخراج الصوت…", "Audio extraction started…"));
    }

    private void showTtsDialog() {
        LinearLayout form = dialogForm();
        EditText content = new EditText(this);
        content.setTextColor(textColor());
        content.setHintTextColor(mutedColor());
        content.setHint(t("اكتب النص الذي تريد تحويله إلى كلام…", "Enter the text to convert to speech…"));
        content.setMinLines(4);
        content.setGravity(Gravity.TOP | Gravity.START);
        content.setBackground(inputBackground());
        form.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(130)));
        new AlertDialog.Builder(this)
                .setTitle(t("تحويل النص إلى ملف صوتي", "Text to speech audio file"))
                .setView(form)
                .setNegativeButton(t("إلغاء", "Cancel"), null)
                .setPositiveButton(t("إنشاء الملف", "Create audio"), (d, w) -> createSpeechFile(content.getText().toString()))
                .show();
    }

    private void createSpeechFile(String text) {
        if (text.trim().isEmpty()) {
            showToast(t("اكتب نصاً أولاً.", "Enter some text first."));
            return;
        }
        File output = new File(getExternalFilesDir(null), "AAS_TTS_" + System.currentTimeMillis() + ".wav");
        final String utteranceId = "aas-tts-" + System.currentTimeMillis();
        final TextToSpeech[] holder = new TextToSpeech[1];
        holder[0] = new TextToSpeech(this, status -> {
            TextToSpeech engine = holder[0];
            if (engine == null) return;
            if (status != TextToSpeech.SUCCESS) {
                engine.shutdown();
                showToast(t("محرك تحويل النص إلى كلام غير متاح.", "Text-to-speech engine is unavailable."));
                return;
            }
            Locale locale = english ? Locale.US : new Locale("ar");
            int languageResult = engine.setLanguage(locale);
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.shutdown();
                showToast(t("اللغة المطلوبة غير مثبتة في محرك النطق على الجهاز.", "The selected voice language is not installed on this device."));
                return;
            }
            engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) {
                    runOnUiThread(() -> {
                        if (output.exists() && output.length() > 44) {
                            addGeneratedFile(Uri.fromFile(output), output.getName());
                            showToast(t("تم إنشاء الملف الصوتي.", "Speech audio file created."));
                        } else {
                            showToast(t("لم ينتج محرك النطق ملفاً صالحاً.", "The speech engine did not create a valid file."));
                        }
                        engine.shutdown();
                    });
                }
                @Override public void onError(String id) {
                    runOnUiThread(() -> showToast(t("فشل تحويل النص إلى كلام.", "Text-to-speech conversion failed.")));
                    engine.shutdown();
                }
            });
            int result = engine.synthesizeToFile(text, null, output, utteranceId);
            if (result == TextToSpeech.ERROR) {
                engine.shutdown();
                showToast(t("تعذر بدء تحويل النص.", "Could not start speech conversion."));
            } else {
                showToast(t("جارٍ إنشاء الملف الصوتي…", "Creating audio file…"));
            }
        });
    }

    private void showSleepDialog() {
        EditText minutes = numberInput("30");
        new AlertDialog.Builder(this)
                .setTitle(t("مؤقت النوم بالدقائق", "Sleep timer in minutes"))
                .setView(minutes)
                .setNegativeButton(t("إلغاء", "Cancel"), null)
                .setPositiveButton(t("بدء", "Start"), (d, w) -> {
                    try {
                        int value = Integer.parseInt(minutes.getText().toString());
                        if (value < 1 || value > 1440) throw new IllegalArgumentException();
                        if (sleepTask != null) mainHandler.removeCallbacks(sleepTask);
                        sleepTask = () -> {
                            if (player != null) player.pause();
                            showToast(t("انتهى مؤقت النوم وتم إيقاف التشغيل.", "Sleep timer ended; playback paused."));
                        };
                        mainHandler.postDelayed(sleepTask, value * 60_000L);
                        showToast(t("تم تشغيل مؤقت النوم.", "Sleep timer started."));
                    } catch (Exception e) {
                        showToast(t("أدخل عدداً بين 1 و1440 دقيقة.", "Enter a value from 1 to 1440 minutes."));
                    }
                }).show();
    }

    private void showSettings() {
        LinearLayout form = dialogForm();
        addLabel(form, t("لغة الواجهة", "Interface language"));
        RadioGroup language = new RadioGroup(this);
        RadioButton arabic = new RadioButton(this);
        arabic.setText("العربية");
        arabic.setTextColor(textColor());
        RadioButton englishButton = new RadioButton(this);
        englishButton.setText("English");
        englishButton.setTextColor(textColor());
        language.addView(arabic);
        language.addView(englishButton);
        (english ? englishButton : arabic).setChecked(true);
        form.addView(language);

        addLabel(form, t("المظهر", "Appearance"));
        RadioGroup theme = new RadioGroup(this);
        RadioButton dark = new RadioButton(this);
        dark.setText(t("داكن", "Dark"));
        dark.setTextColor(textColor());
        RadioButton light = new RadioButton(this);
        light.setText(t("فاتح", "Light"));
        light.setTextColor(textColor());
        theme.addView(dark);
        theme.addView(light);
        (darkTheme ? dark : light).setChecked(true);
        form.addView(theme);

        addLabel(form, t("خانة كود تحديث النظام (للاستخدام المستقبلي)", "System update code field (future use)"));
        EditText updateCode = new EditText(this);
        updateCode.setTextColor(textColor());
        updateCode.setHintTextColor(mutedColor());
        updateCode.setHint(t("أدخل الكود هنا — لا يتم تنفيذه حالياً", "Enter code here — execution is not enabled"));
        updateCode.setText(prefs.getString("future_update_code", ""));
        updateCode.setBackground(inputBackground());
        form.addView(updateCode);
        TextView note = text(t("لن ينفذ التطبيق أي كود تكتبه هنا. الخانة تحفظ النص فقط لحين تطوير نظام تحديث آمن لاحقاً.",
                "The app does not execute code entered here. It only stores the text for a future secure update feature."), 12, false);
        note.setTextColor(mutedColor());
        form.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(t("إعدادات التطبيق", "App settings"))
                .setView(form)
                .setNegativeButton(t("إلغاء", "Cancel"), null)
                .setPositiveButton(t("حفظ", "Save"), (d, w) -> {
                    english = englishButton.isChecked();
                    darkTheme = dark.isChecked();
                    prefs.edit().putBoolean("english", english).putBoolean("dark", darkTheme)
                            .putString("future_update_code", updateCode.getText().toString()).apply();
                    recreate();
                }).show();
    }

    private void showProcessingInfo() {
        String message = t(
                "التشغيل يدعم الملفات التي يستطيع Android/Media3 فك ترميزها. استخراج الصوت والقص يصدّران مسارات AAC إلى M4A؛ الملفات ذات ترميز صوتي آخر قد ترفضها أداة التصدير. تحويل النص إلى كلام يعتمد على محرك TTS المثبت في جهازك. لا يتم تعديل الملف الأصلي عند القص؛ يُنشأ ملف جديد.",
                "Playback supports media codecs available to Android/Media3. Audio extraction and trimming currently export AAC tracks to M4A; other audio codecs may be rejected by the export tool. Text-to-speech uses the voice engine installed on your device. Trimming creates a new file and does not overwrite the original."
        );
        new AlertDialog.Builder(this).setTitle(t("معلومات المعالجة", "Processing information"))
                .setMessage(message).setPositiveButton(t("حسناً", "OK"), null).show();
    }

    private void loadLibrary() {
        library.clear();
        try {
            JSONArray array = new JSONArray(prefs.getString("library", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                library.add(new MediaEntry(obj.getString("uri"), obj.optString("name", "media"),
                        obj.optString("mime", "application/octet-stream"),
                        obj.optString("kind", "audio"), obj.optLong("size", 0),
                        obj.optBoolean("trashed", false)));
            }
        } catch (Exception ignored) { }
    }

    private void saveLibrary() {
        JSONArray array = new JSONArray();
        try {
            for (MediaEntry item : library) {
                JSONObject obj = new JSONObject();
                obj.put("uri", item.uri);
                obj.put("name", item.name);
                obj.put("mime", item.mime);
                obj.put("kind", item.kind);
                obj.put("size", item.size);
                obj.put("trashed", item.trashed);
                array.put(obj);
            }
            prefs.edit().putString("library", array.toString()).apply();
        } catch (Exception ignored) { }
    }

    @Nullable
    private MediaEntry findEntry(String uri) {
        if (uri == null) return null;
        for (MediaEntry item : library) if (uri.equals(item.uri)) return item;
        return null;
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(13), dp(14), dp(13));
        layout.setBackground(cardBackground());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        page.addView(layout, lp);
        return layout;
    }

    private void addHeading(LinearLayout parent, String value) {
        TextView heading = text(value, 17, true);
        heading.setPadding(0, 0, 0, dp(9));
        parent.addView(heading);
    }

    private LinearLayout horizontal() {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        return line;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private TextView text(String value, float size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(textColor());
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(textColor());
        b.setBackground(buttonBackground(false));
        b.setMinHeight(dp(42));
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        return b;
    }

    private Button primaryButton(String value) {
        Button b = button(value);
        b.setTextColor(Color.WHITE);
        b.setBackground(buttonBackground(true));
        return b;
    }

    private GradientDrawable cardBackground() {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                darkTheme ? new int[]{0xFF17263D, 0xFF101A2B} : new int[]{0xFFFFFFFF, 0xFFF2F5FA});
        d.setCornerRadius(dp(18));
        d.setStroke(dp(1), darkTheme ? 0xFF2D405B : 0xFFD7DFEA);
        return d;
    }

    private GradientDrawable buttonBackground(boolean primary) {
        int color = primary ? 0xFF176D9A : (darkTheme ? 0xFF22344F : 0xFFE8EEF7);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(13));
        d.setStroke(dp(1), primary ? 0xFF34B8D8 : (darkTheme ? 0xFF344B68 : 0xFFD0D9E5));
        return d;
    }

    private GradientDrawable inputBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(darkTheme ? 0xFF0B1424 : 0xFFFFFFFF);
        d.setCornerRadius(dp(12));
        d.setStroke(dp(1), darkTheme ? 0xFF344B68 : 0xFFD0D9E5);
        return d;
    }

    private LinearLayout dialogForm() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), dp(8));
        return form;
    }

    private void addLabel(LinearLayout parent, String value) {
        TextView label = text(value, 13, true);
        label.setPadding(0, dp(8), 0, dp(4));
        parent.addView(label);
    }

    private EditText numberInput(String value) {
        EditText input = new EditText(this);
        input.setText(value);
        input.setTextColor(textColor());
        input.setHintTextColor(mutedColor());
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setBackground(inputBackground());
        input.setPadding(dp(10), dp(5), dp(10), dp(5));
        return input;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int bgColor() { return darkTheme ? 0xFF080F1D : 0xFFF4F7FB; }
    private int textColor() { return darkTheme ? 0xFFF4F7FF : 0xFF16243A; }
    private int mutedColor() { return darkTheme ? 0xFFAAB8CB : 0xFF68778D; }
    private String t(String ar, String en) { return english ? en : ar; }

    private String readableSize(long bytes) {
        if (bytes <= 0) return t("حجم غير معروف", "Size unavailable");
        if (bytes < 1024 * 1024) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private String formatTime(long ms) {
        long total = Math.max(0, ms / 1000);
        long hours = total / 3600;
        long minutes = (total % 3600) / 60;
        long seconds = total % 60;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        savePlaybackState();
        if (player != null && currentEntry != null && "video".equals(currentEntry.kind)) player.pause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        savePlaybackState();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        savePlaybackState();
        mainHandler.removeCallbacks(progressRunnable);
        if (sleepTask != null) mainHandler.removeCallbacks(sleepTask);
        if (playerView != null) playerView.setPlayer(null);
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        super.onDestroy();
    }

    private static final class MediaEntry {
        final String uri;
        final String name;
        final String mime;
        final String kind;
        final long size;
        boolean trashed;

        MediaEntry(String uri, String name, String mime, String kind, long size, boolean trashed) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.kind = kind;
            this.size = size;
            this.trashed = trashed;
        }
    }
}
